
__project__ = 'vulrenable_application'
__description__ = 'Damn Simple Vulnerable Python Web Application (DSVPWA)'
__author__ = 'Razi chennouf'
__version__ = '0.0.1'
__url__ = 'https://github.com/Razichennouf/vulrenable_application'
__date__ = '2021/09/21'
